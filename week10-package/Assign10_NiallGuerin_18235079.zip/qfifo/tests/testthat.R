library(testthat)

test_check("qfifo")
